#!/usr/bin/env bash
#
# Clean source directory after running the coverage script.

rm -r build__*
rm -r coverage__*
rm -r source__*

### end of file
